var express = require("express");
var opn = require("opn");

var crossword_json = require("./crossword.js");


var app = express();

app.use(express.static("public"));

app.get("/data", (req,res) => {
    res.json(crossword_json);
})
app.listen(3000, ()=> {
    console.log("listening on port 3000");
    opn("http://localhost:3000/");
});