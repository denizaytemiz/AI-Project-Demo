import requests
from bs4 import BeautifulSoup
import numpy as np
import math
from nltk.corpus import wordnet


URL = "https://www.nytimes.com/crosswords/game/mini/"

# reveal puzzle
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome('C:/Users/toshiba/Desktop/AI_Demo/webdriver/chromedriver.exe')
driver.get(URL)

# OK button in the beginning
button = driver.find_elements_by_xpath('//button[@aria-label="OK"]')[0]
button.click()

# press on reveal puzzle
reveal_puzzle_button = driver.find_elements_by_xpath('//a[text()="Puzzle"]')[1]
driver.execute_script("arguments[0].click();", reveal_puzzle_button)

# press confirm reveal button
confirm_reveal_button = driver.find_elements_by_xpath('//*[@id="root"]/div/div[2]/div[2]/article/div[2]/button[2]')[0]
confirm_reveal_button.click()

# press x
x_button = driver.find_elements_by_xpath('//*[@id="root"]/div/div[2]/div[2]/span')[0]
x_button.click()

g_cells = driver.find_elements_by_xpath('//*[@data-group="cells"]')[0]

grid = g_cells.find_elements_by_tag_name('g')

soup = BeautifulSoup(driver.page_source, 'html.parser')

grid = soup.find(attrs={'data-group':'cells'})

# get all crossword squares
g_elems = grid.find_all('g')

# get crossword dimensions
num_of_squares = len(g_elems)
crossword_dimensions = int(math.sqrt(num_of_squares))

print('Number of squares: ', num_of_squares)
print('Number of sqrt of squares: ', crossword_dimensions)

### get whether grid cells are black or not
# generate array with dimensions of crossword puzzle
isBlackCell = []
temp_text = []
tempura_text = []

for el in g_elems:
    if(el.find('text') == None):
        isBlackCell.append(False)
        temp_text.append(" ")
        tempura_text.append("black")
    else:
        isBlackCell.append(True)
        temp_text.append(el.getText())
        tempura_text.append(el.getText())

# array that shows if cell is black or contains text
print(isBlackCell)
print(temp_text)

### get clues
clues = soup.findAll('ol')

# temp arrays
accross_clues_temp = clues[0].findAll('li')
down_clues_temp = clues[1].findAll('li')

# clues
accross_clues = []
down_clues = []

for clue in accross_clues_temp:
    s = clue.select('span[class*="Clue-label-"]')[0].getText() + ' ' + clue.select('span[class*="Clue-text-"]')[0].getText()
    accross_clues.append(s)

for clue in down_clues_temp:
    s = clue.select('span[class*="Clue-label-"]')[0].getText() + ' ' + clue.select('span[class*="Clue-text-"]')[0].getText()
    down_clues.append(s)
    
print(accross_clues)
print(down_clues)


def extract_answers(answers):
    words = {}
    index = ''

    for row in answers:
        index = row[0][0]
        words[index] = ''
        for letter in row:
            try:
                int(letter[0])
                if len(letter) > 1:
                    words[index] = words[index] + letter[1]
                pass
            except:
                words[index] = words[index] + letter
    return words
# get accross answers
# split crossword
crossword = []

for i in range(0, 5):
    row = []
    for j in range(0, 5):
        row.append(temp_text[i*5 + j][:-1])
    crossword.append(row)

crossword = np.array(crossword)
print('Crossword:\n', crossword)

rows = [''.join(word) for word in crossword]
print('\nRows:\n', rows)

colms = [''.join(word) for word in crossword.T]
print('\nColms:\n', colms)

# form accross words
accross_words = extract_answers(rows)
down_words = extract_answers(colms)

print('\nAccross answers:\n', accross_words)
print('\nDown answers:\n', down_words)

import nltk

nltk.download('wordnet')

import random
from nltk.corpus import wordnet   #Import wordnet from the NLTK
import re

generated_accross_clues = []
generated_down_clues = []

for key, word in accross_words.items():
    synset = wordnet.synsets(word)

    if len(synset) > 1:
        synsetIndex = random.randint(0, len(synset) - 1)
    elif len(synset) == 1:
        synsetIndex = 0

    if len(synset) >= 1:
        temp = synset[synsetIndex].definition().split(';')[0]
        generated_accross_clues.append(key + '. ' + temp[0].upper() + temp[1:])
    else:
        driver.get("https://www.definitions.net/definition/" + word)
        description = driver.find_elements_by_xpath('//p[@class="desc"]')[0].text.split('.')[0]
        insensitive_desc = re.compile( re.escape(word), re.IGNORECASE )
        description = insensitive_desc.sub('___', description)
        description = description[0].upper() + description[1:]
        generated_accross_clues.append(key + '. ' + description)

print('Accross clues:\n', np.array(generated_accross_clues))

for key, word in down_words.items():
    synset = wordnet.synsets(word)

    if len(synset) > 1:
        synsetIndex = random.randint(0, len(synset) - 1)
    elif len(synset) == 1:
        synsetIndex = 0

    if len(synset) >= 1:
        temp = synset[synsetIndex].definition().split(';')[0]
        generated_down_clues.append(key + '. ' + temp[0].upper() + temp[1:])
    else:
        driver.get("https://www.definitions.net/definition/" + word)
        description = driver.find_elements_by_xpath('//p[@class="desc"]')[0].text.split('.')[0]
        insensitive_desc = re.compile( re.escape(word), re.IGNORECASE )
        description = insensitive_desc.sub('___', description)
        description = description[0].upper() + description[1:]
        generated_down_clues.append(key + '. ' + description)

print('\nDown clues:\n', np.array(generated_down_clues))

driver.close()

import json

ret_obj = {
    "accross_clues":accross_clues,
    "down_clues":down_clues,
    "answers":tempura_text,
    "generated_accross_clues":generated_accross_clues,
    "generated_down_clues":generated_down_clues
}

with open('cross.json', 'w') as json_file:
    json.dump(ret_obj, json_file)