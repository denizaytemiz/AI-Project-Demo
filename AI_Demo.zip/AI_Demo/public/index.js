
$(document).ready(function(event){
    let accross = [];
    let down = [];
    let grids = [];
    let gen_accross = [];
    let gen_down = [];
    $.getJSON("http://localhost:3000/data", function(data){
        accross = data.accross_clues;
        down = data.down_clues;
        grids = data.answers;
        gen_accross = data.generated_accross_clues;
        gen_down = data.generated_down_clues;

        console.log(accross);
        console.log(down);
        console.log(grids);
        console.log(gen_accross);
        console.log(gen_down);

        for(let i = 0; i < grids.length; i++){
            let str = "#grid" + (i + 1);
            let str2 = "#number_cont_" + (i + 1);
            if(grids[i] == "black"){
                $(str).addClass("inverted")
                $(str2).hide();
            }
            else{
                let numstr = "#number" + (i+1);
                let charstr = "#char" + (i+1);
                if(grids[i].charAt(0) >= '0' && grids[i].charAt(0) <= '9'){
                    $(numstr).text(grids[i].charAt(0));
                    $(charstr).text(grids[i].charAt(1));
                }
                else{
                    $(charstr).text(grids[i].charAt(1));
                }
            }
        }

        for(let i = 0; i < accross.length; i++){
            let cluestr = "#accross" + (i+1);
            let textstr = accross[i].charAt(0);
            textstr = textstr + ") " + accross[i].substr(1, accross[i].length);
            $(cluestr).text(textstr);
        }

        for(let i = 0; i < down.length; i++){
            let cluestr = "#down" + (i+1);
            let textstr = down[i].charAt(0);
            textstr = textstr + ") " + down[i].substr(1, down[i].length);
            $(cluestr).text(textstr);
        }

        for(let i = 0; i < gen_accross.length; i++){
            let cluestr = "#gaccross" + (i+1);
            let textstr = gen_accross[i].charAt(0);
            textstr = textstr + ") " + gen_accross[i].substr(1, gen_accross[i].length);
            $(cluestr).text(textstr);
        }

        for(let i = 0; i < gen_down.length; i++){
            let textstr = gen_down[i].charAt(0);
            let idx = parseInt(textstr);

            let cluestr = "#gdown" + (idx);
            textstr = textstr + ") " + gen_down[i].substr(1, gen_down[i].length);
            $(cluestr).text(textstr);
        }
        

    })
    const d = new Date();
    const ye = new Intl.DateTimeFormat('en', { year: 'numeric' }).format(d)
    const mo = new Intl.DateTimeFormat('en', { month: 'short' }).format(d)
    const da = new Intl.DateTimeFormat('en', { day: '2-digit' }).format(d)
    const hour = d.getHours();
    const mins = d.getMinutes();
    console.log(hour);
    

    let datestr = "Today: " + `${da}-${mo}-${ye}` +  "  Time:  " + hour + ":" + mins
    $("#infodate").text(datestr);
    $("#infogroup").text("Group Name: JOBTAKER");
});