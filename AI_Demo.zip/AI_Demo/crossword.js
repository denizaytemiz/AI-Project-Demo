var fs = require("fs");

var json = fs.readFileSync("./cross.json");
var read_data = JSON.parse(json);



module.exports = read_data;


